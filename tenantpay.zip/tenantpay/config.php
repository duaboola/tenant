<?php 

    $username="root";
    $password="root"; 
    $host="localhost";
    $db_name="tenantpay";
    $port="8888";
        

    $db=new mysqli($host,$username,$password,$db_name,$port);
       
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
      }

    if($db == false)
    {
        die("ERROR: Could not connect. " . $db->connect_error);
    }
    else{
        
       //echo json_encode("yes");
    }
	
?>