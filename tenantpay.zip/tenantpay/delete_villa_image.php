<?php
include 'config.php';


$villaname=$_POST['villaname'];
$villalocation=$_POST['villalocation'];
$img=$_POST['img'];
  
//  echo json_encode($villaname);
//  echo json_encode($villalocation);
//  echo json_encode($img);

 $querydelete = $db->query("DELETE FROM villagallery WHERE villa_name='".$villaname."' AND villa_location='".$villalocation."' AND image='".$img."'");
 
if ($querydelete)
{
 echo json_encode("Deleted");
}

?>