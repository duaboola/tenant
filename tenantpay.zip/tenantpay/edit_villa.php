<?php 

    include "config.php";

    $id = $_POST['id'];
    $email = $_POST['email'];
    $name = $_POST['name'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $rooms = $_POST['rooms'];
    $bathroom = $_POST['bathroom'];
    $size = $_POST['size'];
    $ewa = $_POST['ewa'];
    $furnished = $_POST['furnished'];
    $pool = $_POST['pool'];
    $garden = $_POST['garden'];
    $security = $_POST['security'];
    $cctv = $_POST['cctv'];
    $parking = $_POST['parking'];
    $bbq = $_POST['bbq'];
    $wifi = $_POST['wifi'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    
            
                $update = "UPDATE `villa` SET `name`='".$name."',`address`='".$address."',`rooms`='".$rooms."',`bathroom`='".$bathroom."',
                `pool`='".$pool."',`size`='".$size."',`ewa`='".$ewa."',`furnished`='".$furnished."',`garden`='".$garden."',
                `security`='".$security."',`cctv`='".$cctv."',`parking`='".$parking."',`bbq`='".$bbq."',`wifi`='".$wifi."',
                `description`='".$description."',`price`='".$price."',`location`='".$location."' WHERE `id` = '".$id."'";
                $query = mysqli_query($db,$update);
                
                if ($query) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            
    
?>