<?php 

include "config.php";
    $email =  $_POST['email'];
    $password =  $_POST['password'];
    $usertype = $_POST['usertype'];

    

    // $json = file_get_contents('php://input');
    // $obj = json_decode($json,true);

    // $sql1 = "SELECT * FROM users";
    // $result1 = mysqli_query($db,$sql1);
    // while($row=mysqli_fetch_assoc($result1))
    //     $test[]=$row;
    // print json_encode($test);
    //$o = mysqli_fetch_object($result1);
    //echo json_encode($result1);

    if ($usertype != 'null')
    {
        if (!empty($email) && !empty($password))

        {
            //print_r($_POST);
            // $email = mysqli_real_escape_string($db,$obj['email']);
            // $password = mysqli_real_escape_string($db,$obj['password']);
            // $usertype = mysqli_real_escape_string($db,$obj['usertype']);
            //print json_encode($email);
            $sql = "SELECT * FROM users WHERE email = '$email' AND password ='$password' AND usertype = '$usertype'";
            
        

            $result = mysqli_query($db,$sql);
            $row=mysqli_fetch_assoc($result);
            $count = mysqli_num_rows($result);
            //echo json_encode($count);
            //echo json_encode($row);
            //echo json_encode($result);
            
            if ($count > 0)
            {
                //echo json_encode($result);
                //echo json_encode("Success");
                // if ($usertype=='Tenant')
                // {
                //     echo json_encode("SuccessT");
                // }
                // else {
                //     echo json_encode("SuccessL");
                // }
                echo json_encode("Success");
            }
            else
            { 
                echo json_encode("Error");
            }
        }
    }
    else
    {
        echo json_encode("No usertype");
    }
    

    
?>