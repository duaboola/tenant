<?php 

    include "config.php";

    //$email =  $_POST['email'];
    $email =  $_POST['email'];
    $usertype = $_POST['usertype'];

    

   
        if (!empty($email))
        {
            $sql2 = "SELECT * FROM users WHERE email = '$email'";
            
        

            $result2 = mysqli_query($db,$sql2);
            $row2=mysqli_fetch_assoc($result2);
            $count2 = mysqli_num_rows($row2);
            echo json_encode($email);
            echo json_encode($count2);
            if($count2 > 0){
                $data2[] = $row2;
                echo json_encode($data2);
            }else{
                echo json_encode("Error");
            }
            
        }
            
            
        
    
    

    
?>