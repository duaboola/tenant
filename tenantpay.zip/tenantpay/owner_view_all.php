<?php
include 'config.php';


$email=$_POST['email'];
 
//  echo json_encode($email);

 $query = $db->query("SELECT * FROM properties WHERE owner_email='".$email."'");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 echo json_encode($result);



?>