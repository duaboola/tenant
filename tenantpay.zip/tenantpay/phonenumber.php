<?php
include 'config.php';


$villaname=$_POST['villaname'];
$villalocation=$_POST['villalocation'];
  
echo json_encode($villaname);
echo json_encode($villalocation);

 $query = $db->query("SELECT owner_id FROM villa WHERE name='".$villaname."' AND location='".$villalocation."' ");
 //echo json_encode($query);

 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 $query1 = $db->query("SELECT mobile from users WHERE email='".$result."'");
 //echo json_encode($query1);


 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }
 echo json_encode($result);
 return $result;

?>