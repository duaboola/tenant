<?php 

include "../../config.php";

$email = $_POST['email'];
$id = $_POST['id'];
  $fname = $_POST['fname'];
  $bname = $_POST['bname'];
  $location = $_POST['location'];
  $address = $_POST['address'];
  $rooms = $_POST['rooms'];
  $bathroom = $_POST['bathroom'];
  $size = $_POST['size'];
  $ewa = $_POST['ewa'];
  $furnished = $_POST['furnished'];
  $pool = $_POST['pool'];
  $garden = $_POST['garden'];
  $security = $_POST['security'];
  $cctv = $_POST['cctv'];
  $parking = $_POST['parking'];
  $bbq = $_POST['bbq'];
  $wifi = $_POST['wifi'];
  $description = $_POST['description'];
  $price = $_POST['price'];
  $type = $_POST['type'];
    
  //echo json_encode($id);


                $update = "UPDATE `flat` SET `flat_name`='$fname',`building_name`='$bname',`location`='$location',
                `address`='$address',`rooms`='$rooms',`bathrooms`='$bathroom',`size`='$size',`ewa`='$ewa',
                `furnished`='$furnished',`pool`='$pool',`garden`='$garden',`security`='$security',`cctv`='$cctv',
                `parking`='$parking',`wifi`='$wifi',`description`='$description',`price`='$price',`type`='$type' WHERE
                `id` = '".$id."'";
             
                // $update = "UPDATE `flat` SET `flat_name`='".$fname."',`building_name`='".$bname."',`address`='".$address."',`rooms`='".$rooms."',`bathrooms`='".$bathroom."',
                // `pool`='".$pool."',`size`='".$size."',`ewa`='".$ewa."',`furnished`='".$furnished."',`garden`='".$garden."',
                // `security`='".$security."',`cctv`='".$cctv."',`parking`='".$parking."',`bbq`='".$bbq."',`wifi`='".$wifi."',
                // `description`='".$description."',`price`='".$price."',`location`='".$location."',`type`='".$type."' WHERE `id` = '".$id."'";
                $query = mysqli_query($db,$update);
                // echo json_encode($query);
                // echo json_encode($update);
                
                if ($query) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            
    
?>