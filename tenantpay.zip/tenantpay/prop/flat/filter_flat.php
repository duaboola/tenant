<?php


include "../../config.php";

$room = $_POST['rooms'];
$bathroom = $_POST['bathroom'];
$ewa = $_POST['ewa'];
$furnished = $_POST['furnished'];
$minprice = $_POST['minprice'];
$maxprice = $_POST['maxprice'];
$type = $_POST['type'];



$all_conditions = '';

if($room != "All")
    $conditions[] = "rooms = '".$room."'";

if($bathroom != "All")
    $conditions[] = "bathrooms = '".$bathroom."'";

if($ewa != "All")
    $conditions[] = "ewa = '".$ewa."'";

if($furnished != "All")
    $conditions[] = "furnished = '".$furnished."'";

if($type != "All")
    $conditions[] = "type = '".$type."'";

if($minprice != "0" || $maxprice != "20000")
    $conditions[] = "( price BETWEEN '".$minprice."' AND '".$maxprice."' )";

if(count($conditions)>0)
    $all_conditions = implode(" and ",$conditions);

if($all_conditions != "")
{
    $all_conditions = "where ".$all_conditions;
}
else
{
    $all_conditions = "";
}

//echo json_encode($room);

//$sql = "SELECT * FROM villa $all_conditions";

// $records_posts = $db->get_results($sql);
// return $records_posts;
//echo json_encode($all_conditions);

$result = $db->query("SELECT * FROM flat $all_conditions");
//echo json_encode($result);
if ($result) {
    while($row = $result->fetch_assoc()){
        $list[]= $row;
    }
    echo json_encode($list);
}



// // echo json_encode($email);
// //echo json_encode($search);

// $list = array();

// $s=("SELECT * FROM villa WHERE name LIKE '%".$search."%' OR location LIKE '%".$search."%'" );
// $result= mysqli_query($db,$s);
// //$result = $db->query("SELECT * FROM villa WHERE email='$email' AND name LIKE '%".$search."%'");
// // echo json_encode($result);
// // echo json_encode($s);
// if ($result) {
//     while($row = $result->fetch_assoc()){
//         $list[]= $row;
//     }
//     echo json_encode($list);
// }

?>