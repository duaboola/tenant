<?php

    include "config.php";

    $image[] = $_FILES['image']['name'];
    $tmpFile[] = $_FILES['image']['tmp_name'];
    $flatname = $_POST['flat'];
    $buildingname = $_POST['building'];
    $flatlocation = $_POST['flatlocation'];
    
    // echo ($villaname);
    // echo ($villalocation);

    function updateName($value)
    {
        $flatname = $_POST['flat'];
        $buildingname = $_POST['building'];
        $flatlocation = $_POST['flatlocation'];
                    //echo json_encode($villaname);
                    //echo json_encode($villalocation);
                    $sql = ("UPDATE `flatgallery` SET `flat_name`='".$flatname."',`building_name`='".$buildinganame."',`location`='".$flatlocation."', WHERE `image`='".$value."'");
                        $save2 = mysqli_query($db,$sql)or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($this->db_link), E_USER_ERROR);
                        echo $sql;
                        if ($save2)
                        {
                            echo json_encode("Success again");
                            echo $sql;
                        }
                        else
                        {
                            echo json_encode("Error");
                        }
    }

    foreach ($image as $key => $value)
    {
        foreach ($tmpFile as $key => $tmpFilevalue)
        {
            if (move_uploaded_file($tmpFilevalue,'gallery/flat/'.$value))
            {
                $save =("INSERT INTO flatgallery (flat_name,building_name,location,image) VALUES ('".$flataname."','".$buildingname."','".$flatlocation."','".$value."')");
                $save1 = mysqli_query($db,$save);
                if ($save1)
                {
                    echo json_encode("Success");
                    //echo $save;
                    //updateName($value);

                }
                else
                {
                    echo json_encode(array("message"=>"Error".mysqli_error($db)));
                }
                
            }
        }
                    
    }
    
    

?>