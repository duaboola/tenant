<?php
include '../../config.php';


$email=$_POST['email'];
 
 

 $query = $db->query("SELECT * FROM flat where tenant_email IS NULL");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 echo json_encode($result);



?>