<?php
include '../../config.php';


$flatname=$_POST['flatname'];
$buildingname=$_POST['buildingname'];
$flatlocation=$_POST['flatlocation'];
  
//  echo json_encode($flatname);
// echo json_encode($flatlocation);

 $query = $db->query("SELECT * FROM flatgallery WHERE flat_name='$flatname' AND buiding_name='$buildingname' AND location='$flatlocation' ");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 if (!$query) {
    $query1 = $db->query("SELECT * FROM flatgallery WHERE flat_name='dummy' AND buiding_name='dummy' AND location='dummy'");
    
    $result = array();
    while ($rowdata = $query1->fetch_assoc()){
        $result[] = $rowdata;
     }
 }

 echo json_encode($result);

?>