<?php
include '../../config.php';


$email=$_POST['email'];
 
 

 $query = $db->query("SELECT * FROM flat WHERE owner_email='".$email."'");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 echo json_encode($result);



?>