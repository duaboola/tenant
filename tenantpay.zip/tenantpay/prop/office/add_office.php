<?php 
  

  include "../../config.php";

    $email = $_POST['email'];
    $oname = $_POST['oname'];
    $bname = $_POST['bname'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $rooms = $_POST['rooms'];
    $reception = $_POST['reception'];
    $dining = $_POST['dining'];
    $meeting = $_POST['meeting'];
    $capacity = $_POST['capacity'];
    $size = $_POST['size'];
    $ewa = $_POST['ewa'];
    $furnished = $_POST['furnished'];
    $eco = $_POST['eco'];
    $security = $_POST['security'];
    $cctv = $_POST['cctv'];
    $parking = $_POST['parking'];
    $wifi = $_POST['wifi'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    //echo json_encode($name);
    
    if ($rooms!= 'null' && $ewa!= 'null' && $furnished!= 'null'  && $reception !='null' && $dining !='null'  && $meeting !='null'  && $capacity !='null')
    
    {

            $sql = "SELECT * FROM office WHERE owner_email = '$email' AND office_name = '$oname' AND building_name = '$bname' AND location = '$location' ";

            $result = mysqli_query($db,$sql);
            $count = mysqli_num_rows($result);
            
        
            if ($count > 0)
            {
                echo json_encode("Error");
            }
            else
            {   
                $insert = "INSERT INTO `office`( `owner_email`, `office_name`, `building_name`, `location`, `address`, `rooms`, `reception`, `dining`, `capacity`, `size`, `ewa`, `furnished`,`cctv`, `meetingspace`, `security`, `wifi`, `ecofriendly`, `parking`, `description`, `price`) 
                VALUES ('$email','$oname','$bname','$location','$address','$rooms','$reception', '$dining', '$capacity', '$size','$ewa','$furnished','$cctv','$meeting', '$security','$wifi','$eco','$parking','$description','$price')";

                // $insert = "INSERT INTO `flat`(`owner_email`, `flat_name`, `building_name`, `location`, `address`, `rooms`, `bathrooms`, `size`, `ewa`, `furnished`, `pool`, `garden`, `security`, `cctv`, `parking`, `wifi`, `description`, `price`, `type`) 
                // VALUES ('$email','$fname','$bname','$location','$address','$rooms','$bathroom','$size','$ewa','$furnished','$pool','$garden','$security','$cctv','$parking','$wifi','$description','$price','$type')";

    
                $query = mysqli_query($db,$insert);
                
                $name = $oname.",".$bname;
                $insert2= "INSERT INTO `properties`(`name`, `location`, `type`, `rent`, `owner_email`) 
                VALUES ('$name','$location','Office','$price','$email')";
                $query2 = mysqli_query($db,$insert2);

                //echo json_encode($query2);
                //echo json_encode($insert2);

                if ($query and $query2) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            }
    }
    else{
        echo json_encode("Not Complete");
    }

?>