<?php 

include "../../config.php";


$id = $_POST['id'];
$email = $_POST['email'];
    $oname = $_POST['oname'];
    $bname = $_POST['bname'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $rooms = $_POST['rooms'];
    $reception = $_POST['reception'];
    $dining = $_POST['dining'];
    $meeting = $_POST['meeting'];
    $capacity = $_POST['capacity'];
    $size = $_POST['size'];
    $ewa = $_POST['ewa'];
    $furnished = $_POST['furnished'];
    $eco = $_POST['eco'];
    $security = $_POST['security'];
    $cctv = $_POST['cctv'];
    $parking = $_POST['parking'];
    $wifi = $_POST['wifi'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    
  //echo json_encode($id);
  $update = "UPDATE `office` SET `office_name`='$oname',`building_name`='$bname',`location`='$location',
  `address`='$address',`rooms`='$rooms',`reception`='$reception',`dining`='$dining',
  `capacity`='$capacity',`size`='$size',`ewa`='$ewa',`furnished`='$furnished',`cctv`='$cctv',
  `meetingspace`='$meeting',`security`='$security',`wifi`='$wifi',`ecofriendly`='$eco',
  `parking`='$parking',`description`='$description',`price`='$price' WHERE `id` = '".$id."'";

//   $update = "UPDATE `shop` SET `shop_name`='$sname',`location`='$location',`address`='$address',
//   `rooms`='$rooms',`size`='$size',`ewa`='$ewa',`furnished`='$furnished',`cctv`='$cctv',
//   `parking`='$parking',`wifi`='$wifi',`description`='$description',`price`='$price' WHERE `id` = '".$id."'";

  
  $query = mysqli_query($db,$update);
  
  if ($query) {
      echo json_encode("Success");
  }
  else {
      echo json_encode("Try Again");
  }
    
?>