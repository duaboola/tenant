<?php


include "../../config.php";

$email = $_POST['email'];
$search = $_POST['title'];

// echo json_encode($email);
//echo json_encode($search);

$list = array();

$s=("SELECT * FROM office WHERE office_name  LIKE '%".$search."%' OR building_name  LIKE '%".$search."%' OR location LIKE '%".$search."%'");
$result= mysqli_query($db,$s);

if ($result) {
    while($row = $result->fetch_assoc()){
        $list[]= $row;
    }
    echo json_encode($list);
}

?>