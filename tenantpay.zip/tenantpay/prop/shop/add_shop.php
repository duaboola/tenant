<?php 
  

  include "../../config.php";

    $email = $_POST['email'];
    $sname = $_POST['sname'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $rooms = $_POST['rooms'];
    $size = $_POST['size'];
    $ewa = $_POST['ewa'];
    $furnished = $_POST['furnished'];
    $wifi = $_POST['wifi'];
    $cctv = $_POST['cctv'];
    $parking = $_POST['parking'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    //echo json_encode($name);
    
    if ($rooms!= 'null' && $ewa!= 'null' && $furnished!= 'null')
    
    {

            $sql = "SELECT * FROM shop WHERE owner_email = '$email' AND shop_name = '$sname' AND location = '$location' AND address = '$address' ";

            $result = mysqli_query($db,$sql);
            $count = mysqli_num_rows($result);
            
        
            if ($count > 0)
            {
                echo json_encode("Error");
            }
            else
            {   

                $insert = "INSERT INTO `shop`(`owner_email`, `shop_name`, `location`, `address`, `rooms`, `size`, `ewa`, `furnished`, `cctv`, `parking`, `wifi`, `description`, `price`)
                VALUES ('$email','$sname','$location','$address','$rooms','$size','$ewa','$furnished','$cctv','$parking', '$wifi', '$description','$price')";


                // $insert = "INSERT INTO `office`( `owner_email`, `office_name`, `building_name`, `location`, `address`, `rooms`, `reception`, `dining`, `capacity`, `size`, `ewa`, `furnished`,`cctv`, `meetingspace`, `security`, `wifi`, `ecofriendly`, `parking`, `description`, `price`) 
                // VALUES ('$email','$oname','$bname','$location','$address','$rooms','$reception', '$dining', '$capacity', '$size','$ewa','$furnished','$cctv','$meeting', '$security','$wifi','$eco','$parking','$description','$price')";

                // $insert = "INSERT INTO `flat`(`owner_email`, `flat_name`, `building_name`, `location`, `address`, `rooms`, `bathrooms`, `size`, `ewa`, `furnished`, `pool`, `garden`, `security`, `cctv`, `parking`, `wifi`, `description`, `price`, `type`) 
                // VALUES ('$email','$fname','$bname','$location','$address','$rooms','$bathroom','$size','$ewa','$furnished','$pool','$garden','$security','$cctv','$parking','$wifi','$description','$price','$type')";

    
                $query = mysqli_query($db,$insert);
                
                
                $insert2= "INSERT INTO `properties`(`name`, `location`, `type`, `rent`, `owner_email`) 
                VALUES ('$sname','$location','Office','$price','$email')";
                $query2 = mysqli_query($db,$insert2);

                // echo json_encode($query);
                // echo json_encode($query2);

                if ($query and $query2) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            }
    }
    else{
        echo json_encode("Not Complete");
    }

?>