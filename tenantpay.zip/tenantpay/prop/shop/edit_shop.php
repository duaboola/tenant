<?php 

include "../../config.php";


$id = $_POST['id'];
$email = $_POST['email'];
$sname = $_POST['name'];
$location = $_POST['location'];
$address = $_POST['address'];
$rooms = $_POST['rooms'];
$size = $_POST['size'];
$ewa = $_POST['ewa'];
$furnished = $_POST['furnished'];
$wifi = $_POST['wifi'];
$cctv = $_POST['cctv'];
$parking = $_POST['parking'];
$description = $_POST['description'];
$price = $_POST['price'];

    
  //echo json_encode($id);

  $update = "UPDATE `shop` SET `shop_name`='$sname',`location`='$location',`address`='$address',
  `rooms`='$rooms',`size`='$size',`ewa`='$ewa',`furnished`='$furnished',`cctv`='$cctv',
  `parking`='$parking',`wifi`='$wifi',`description`='$description',`price`='$price' WHERE `id` = '".$id."'";

  
  $query = mysqli_query($db,$update);
  
  if ($query) {
      echo json_encode("Success");
  }
  else {
      echo json_encode("Try Again");
  }
    
?>