<?php


include "../../config.php";

$email = $_POST['email'];
$search = $_POST['title'];

// echo json_encode($email);
//echo json_encode($search);

$list = array();

$s=("SELECT * FROM shop WHERE owner_email='$email' AND shop_name LIKE '%".$search."%' ");
$result= mysqli_query($db,$s);

if ($result) {
    while($row = $result->fetch_assoc()){
        $list[]= $row;
    }
    echo json_encode($list);
}

?>