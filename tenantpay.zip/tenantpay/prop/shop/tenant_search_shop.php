<?php


include "../../config.php";


$search = $_POST['title'];



$list = array();

$s=("SELECT * FROM villa WHERE shop_name LIKE '%".$search."%' OR location LIKE '%".$search."%'" );
$result= mysqli_query($db,$s);

if ($result) {
    while($row = $result->fetch_assoc()){
        $list[]= $row;
    }
    echo json_encode($list);
}

?>