<?php 

    include "../../config.php";

    $email = $_POST['email'];
    $name = $_POST['name'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $rooms = $_POST['rooms'];
    $bathroom = $_POST['bathroom'];
    $size = $_POST['size'];
    $ewa = $_POST['ewa'];
    $furnished = $_POST['furnished'];
    $pool = $_POST['pool'];
    $garden = $_POST['garden'];
    $security = $_POST['security'];
    $cctv = $_POST['cctv'];
    $parking = $_POST['parking'];
    $bbq = $_POST['bbq'];
    $wifi = $_POST['wifi'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    //echo json_encode($name);
    
    if ($rooms!= 'null' && $bathroom!= 'null'  && $ewa!= 'null' && $furnished!= 'null')
    
    {

            $sql = "SELECT * FROM villa WHERE owner_id = '$email' AND name = '$name' AND location='$location'";

            $result = mysqli_query($db,$sql);
            $count = mysqli_num_rows($result);
            
        
            if ($count > 0)
            {
                echo json_encode("Error");
            }
            else
            {   
                //$insert = "INSERT INTO `villa`(`name`, `address`, `owner_id`, `rooms`, `bathroom`,`pool`) VALUES ('$name','$address','$email','$rooms', '$bathroom','$pool')";
                $insert = "INSERT INTO `villa`(`owner_id`, `name`, `location`, `address`, `rooms`, `bathroom`, `size`, `ewa`, `furnished`, `pool`, `garden`, `security`, `cctv`, `parking`, `bbq`, `wifi`, `description`, `price`) 
                 VALUES ('$email','$name','$location','$address','$rooms','$bathroom','$size','$ewa','$furnished','$pool','$garden','$security','$cctv','$parking','$bbq','$wifi','$description',$price)";
                $query = mysqli_query($db,$insert);
               // $e = mysqli_error($query);
                // $q= "SELECT * FROM villa";
                // $q1 = mysqli_query($db,$insert);
                // $c = mysqli_num_rows($q1);

                //echo json_encode($query);
                //echo json_encode($insert);
                //echo json_encode($e);

                $insert2= "INSERT INTO `properties`(`name`, `location`, `type`, `rent`, `owner_email`) 
                VALUES ('$name','$location','Villa','$price','$email')";
                $query2 = mysqli_query($db,$insert2);

                //echo json_encode($query2);
                //echo json_encode($insert2);

                if ($query and $query2) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            }
    }
    else{
        echo json_encode("Not Complete");
    }
    //INSERT INTO `villa`(`name`, `address`, `owner_id`) VALUES ('tester','tester','tester')
?>