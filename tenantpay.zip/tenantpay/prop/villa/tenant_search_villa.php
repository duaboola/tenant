<?php


include "../../config.php";

//$email = $_POST['email'];
$search = $_POST['title'];

// echo json_encode($email);
//echo json_encode($search);

$list = array();

$s=("SELECT * FROM villa WHERE name LIKE '%".$search."%' OR location LIKE '%".$search."%'" );
$result= mysqli_query($db,$s);
//$result = $db->query("SELECT * FROM villa WHERE email='$email' AND name LIKE '%".$search."%'");
// echo json_encode($result);
// echo json_encode($s);
if ($result) {
    while($row = $result->fetch_assoc()){
        $list[]= $row;
    }
    echo json_encode($list);
}

?>