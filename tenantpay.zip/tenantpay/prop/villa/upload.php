<?php

     include "../../config.php";

    

    // $images[] = $_FILES['image']['name'];
    // $tmpFile[] = $_FILES['image']['tmp_name'];
    $image = $_POST['image'];
    $villaname = $_POST['villa'];
    $villalocation = $_POST['location'];
    // echo ($villaname);
    //  echo ($villalocation);
    //  echo ($image);
    $insert = "INSERT INTO villagallery (villa_name,villa_location,image) VALUES ('$villaname','$villalocation','$image')";
    $query = mysqli_query($db,$insert);
    if ($query)
    {
        echo json_encode("Success");
    }
    else
    {
        echo json_encode("error");
    }
    

    
    
//     if(isset($_FILES["file"])){
//         //directory to upload file
//         $target_dir = "files/"; //create folder files/ to save file
//         $filename = $_FILES["file"]["name"]; 
//         //name of file
//         //$_FILES["file"]["size"] get the size of file
//         //you can validate here extension and size to upload file.
    
//         $savefile = "$target_dir/$filename";
//         //complete path to save file
    
//         if(move_uploaded_file($_FILES["file"]["tmp_name"], $savefile)) {
//             $return["error"] = false;
//             //upload successful
//         }else{
//             $return["error"] = true;
//             $return["msg"] =  "Error during saving file.";
//         }
//     }else{
//         $return["error"] = true;
//         $return["msg"] =  "No file is sublitted.";
//     }
    
//     header('Content-Type: application/json');
//     // tell browser that its a json data
//     echo json_encode($return);
//     //converting array to JSON string


     

    //  $sql = ("UPDATE `villagallery` SET `villa_name`='".$villaname."',`villa_location`='".$villalocation."', WHERE `image`='".$realImage."'");
    //                     $save2 = mysqli_query($db,$sql)or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($this->db_link), E_USER_ERROR);
    //                    // echo $sql;
    //                     if ($save2)
    //                     {
    //                         echo json_encode("Success again");
    //                         file_put_contents($name, $realImage);
    //                     //    echo $sql;
    //                     }
    //                     else
    //                     {
    //                         echo json_encode("Error");
    //                     }
 
    
 
    //echo "Image Uploaded Successfully.";

    // function updateName($value)
    // {
    //                 
    //                 $sql = ("UPDATE `villagallery` SET `villa_name`='".$villaname."',`villa_location`='".$villalocation."', WHERE `image`='".$value."'");
    //                     $save2 = mysqli_query($db,$sql)or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($this->db_link), E_USER_ERROR);
    //                    // echo $sql;
    //                     if ($save2)
    //                     {
    //                         echo json_encode("Success again");
    //                     //    echo $sql;
    //                     }
    //                     else
    //                     {
    //                         echo json_encode("Error");
    //                     }
    // }

    // foreach ($images as $key => $value)
    // {
    //     foreach ($tmpFile as $key => $tmpFilevalue)
    //     {
    //         if (move_uploaded_file($tmpFilevalue,'gallery/villa/'.$value))
    //         {
    //             $save =("INSERT INTO villagallery (villa_name,villa_location,image) VALUES ('".$villaname."','".$villalocation."','".$value."')");
    //             $save1 = mysqli_query($db,$save);
    //             if ($save1)
    //             {
    //                 echo json_encode("Success");
    //                 //echo $save;
    //                 //updateName($value);

    //             }
    //             else
    //             {
    //                 echo json_encode(array("message"=>"Error".mysqli_error($db)));
    //             }
                
    //         }
    //     }
                    
    // }
    
    

?>