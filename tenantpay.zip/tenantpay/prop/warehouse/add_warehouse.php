<?php 
  

  include "../../config.php";

    $email = $_POST['email'];
    $wname = $_POST['wname'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $rooms = $_POST['rooms'];
    $size = $_POST['size'];
    $ewa = $_POST['ewa'];
    $furnished = $_POST['furnished'];
    $security = $_POST['security'];
    $cctv = $_POST['cctv'];
    $parking = $_POST['parking'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    //echo json_encode($name);
    
    if ($rooms!= 'null' && $ewa!= 'null' && $furnished!= 'null')
    
    {

            $sql = "SELECT * FROM warehouse WHERE owner_email = '$email' AND warehouse_name = '$wname' AND address = '$address'AND location = '$location' ";

            $result = mysqli_query($db,$sql);
            $count = mysqli_num_rows($result);
            
        
            if ($count > 0)
            {
                echo json_encode("Error");
            }
            else
            {   
                $insert = "INSERT INTO `warehouse`(`owner_email`, `warehouse_name`, `location`, `address`, `room`, `size`, `ewa`, `furnished`, `parking`, `security`, `cctv`, `description`, `price`) 
                VALUES ('$email','$wname','$location','$address','$rooms','$size','$ewa','$furnished','$parking','$security','$cctv','$description', '$price')
";

                
                // $insert = "INSERT INTO `warehouse`(`owner_email`, `warehouse_name`, `location`, `address`, `room`, `size`, `ewa`, `furnished`, `parking`, `security`, `cctv`, `description`, `price`)
                //  VALUES ('$email','$wname','$location','$address','$rooms','$size','$ewa','$furnished','$parking','$security','$cctv','$description', '$price')";
                
                $query = mysqli_query($db,$insert);
                
                $insert2= "INSERT INTO `properties`(`name`, `location`, `type`, `rent`, `owner_email`) 
                VALUES ('$wname','$location','Warehouse','$price','$email')";
                $query2 = mysqli_query($db,$insert2);

                //
                // echo json_encode($query);
                // echo json_encode($query2);
                //echo json_encode($insert2);

                if ($query and $query2) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            }
    }
    else{
        echo json_encode("Not Complete");
    }

?>