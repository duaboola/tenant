<?php


include "../../config.php";

$room = $_POST['rooms'];
$ewa = $_POST['ewa'];
$furnished = $_POST['furnished'];
$minprice = $_POST['minprice'];
$maxprice = $_POST['maxprice'];



$all_conditions = '';

if($room != "All")
    $conditions[] = "room = '".$room."'";

if($ewa != "All")
    $conditions[] = "ewa = '".$ewa."'";

if($furnished != "All")
    $conditions[] = "furnished = '".$furnished."'";

if($minprice != "0" || $maxprice != "20000")
    $conditions[] = "( price BETWEEN '".$minprice."' AND '".$maxprice."' )";

if(count($conditions)>0)
    $all_conditions = implode(" and ",$conditions);

if($all_conditions != "")
{
    $all_conditions = "where ".$all_conditions;
}
else
{
    $all_conditions = "";
}

//echo json_encode($room);

//$sql = "SELECT * FROM villa $all_conditions";

// $records_posts = $db->get_results($sql);
// return $records_posts;
//echo json_encode($all_conditions);

$result = $db->query("SELECT * FROM warehouse $all_conditions");
//echo json_encode($result);
if ($result) {
    while($row = $result->fetch_assoc()){
        $list[]= $row;
    }
    echo json_encode($list);
}




?>