<?php
include '../../config.php';



 
 

 $query = $db->query("SELECT * FROM warehouse WHERE tenant_email IS NULL");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 echo json_encode($result);



?>