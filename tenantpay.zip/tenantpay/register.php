<?php 

    require_once "config.php";

    $email = $_POST['email'];
    $password = $_POST['password'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $cpr = $_POST['cpr'];
    $mobile = $_POST['mobile'];
    $usertype = $_POST['usertype'];

    if (!empty($email) && !empty($password) && !empty($fname) && !empty($lname) && !empty($cpr))
    //if (!empty($email) && !empty($password) && !empty($fname) && !empty($lname) && !empty($mobile) && !empty($cpr) && !empty($usertype) )
    {

            $sql = "SELECT * FROM users WHERE email = '$email' AND fname = '$fname'";

            $result = mysqli_query($db,$sql);
            $count = mysqli_num_rows($result);
            
        
            if ($count > 0)
            {
                // while($row=mysqli_fetch_array($resultsearch))
                // {
                //     $res["success"] = "3";
                //     $resu["message"] = "User Already exist";
                //     //echo json_encode($res);
                //     mysqli_close($db);
                // }
                //echo json_encode($result);
                echo json_encode("Error");
            }
            else
            {
                $insert = "INSERT INTO users (email,password,fname,lname,cpr,mobile,usertype) VALUES ('$email','$password','$fname','$lname','$cpr','$mobile','$usertype')";
                $query = mysqli_query($db,$insert);
                if ($query) {
                    echo json_encode("Success");
                }
                else {
                    echo json_encode("Try Again");
                }
            }
    }
    else{
        echo json_encode("Not Complete");
    }
?>