<?php

    include "config.php";
    // ini_set('display_errors',1);
    // ini_set('display_startup_errors',1);
    // error_reporting(E_ALL);

    // $query1 = "SELECT * FROM users WHERE email = 'test'";
    // $result1 = mysqli_query($db,$query1);
    // $row=mysqli_fetch_assoc($result1);
    // $count = mysqli_num_rows($result1);
    // //echo json_encode($query1); 
    // echo json_encode($count); 
    // echo json_encode($result1);
    // echo json_encode($row);

    // if ($count>0)
    // {
    //     echo json_encode("yes");
    // }

    $name=$_POST['name'];
    echo $name;
    
    

?>