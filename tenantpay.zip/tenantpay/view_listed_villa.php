<?php
include 'config.php';


$email=$_POST['email'];
 
 

 $query = $db->query("SELECT * FROM villa WHERE owner_id='".$email."'");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 echo json_encode($result);



?>