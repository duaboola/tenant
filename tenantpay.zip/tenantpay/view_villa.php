<?php
 
 include 'config.php';

 $query = $db->query("SELECT * FROM villa");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 echo json_encode($result);



?>