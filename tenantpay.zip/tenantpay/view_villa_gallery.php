<?php
include 'config.php';


$villaname=$_POST['villaname'];
$villalocation=$_POST['villalocation'];
  
// echo json_encode($villaname);
// echo json_encode($villalocation);

 $query = $db->query("SELECT * FROM villagallery WHERE villa_name='".$villaname."' AND villa_location='".$villalocation."' ");
 $result = array();

 while ($rowdata = $query->fetch_assoc()){
    $result[] = $rowdata;
 }

 if (!$result) {
    $query1 = $db->query("SELECT * FROM villagallery WHERE villa_name='dummy' AND villa_location='dummy' ");
    
    $result = array();
    while ($rowdata = $query1->fetch_assoc()){
        $result[] = $rowdata;
     }
 }

 echo json_encode($result);

?>